.\objects\codigoarmoptimizado.o: codigoARMOptimizado.s
