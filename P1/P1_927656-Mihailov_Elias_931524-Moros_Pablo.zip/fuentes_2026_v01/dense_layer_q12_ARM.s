; Traducción de dense_layer_C, recibe como parámetros const int16_t *input, const int16_t *weights, const int16_t *bias, int16_t *output, uint16_t input_size, uint16_t output_size, int16_t clamp_min, int16_t clamp_max
; al igual que la función original en C, solo que en formato "half word" para datos de 16 bits (2 bytes).
; Los primeros 4 argumentos se guardan en los registros r0-r3, el resto de parámetros se guardan en pila.
; Registros utilizados: r0-r3, registros de tipo "argumento" los cuales pueden ser tanto los argumentos const int16_t *input, const int16_t *weights, const int16_t *bias, int16_t *output
; como los "clamps" o la variable "y", el registro r4 es una copia del parametro input, r5 de weights, r6 de bias, r7 de output, r8 de input_size, r9 de output_size,
; r10 es la variable del bucle "o", r11 es la variable checksum y r12 es una variable temporal, que sirve tanto para calcular o * input_size * 2 como para o * 2.
; r13 (sp) es el puntero a pila, r14 (lr) es el link register, esencial para tener la dirección de retorno en suburtinas
	AREA codigo, CODE, READONLY
	EXPORT  dense_layer_q12_ARM_Deprecated
	IMPORT  neuron_q12_Deprecated
	
dense_layer_q12_ARM_Deprecated							
	PUSH {r4-r11, lr}		; Añadiremos en pila desde r4 a r7 los valores de los registros parámetro (r0-r3), el resto de parámetros que no caben entre r0 y r3 y las variables checksum y o 
	sub sp, sp, #4			; Añadir a memoria, esto se hace para alinear el sp a 8 bytes porque la función en c lo exige
	mov r4, r0              ; input
    mov r5, r1          	; weights
    mov r6, r2              ; bias
    mov r7, r3              ; output
    ldr r8, [sp, #40]       ; input_size
    ldr r9, [sp, #44]       ; output_size
    mov r10, #0             ; o = 0
    mov r11, #0             ; checksum = 0
	ldr r0, [sp, #52]		; r0=clamp_max
	str r0, [sp, #-4]!		; clamp_max se almacena en sp, sp empuja a la direccion original de sp
	ldr r0, [sp, #52]		; r0=clamp_min
	str r0, [sp, #-4]!		; clamp_min se almacena en sp, sp empuja a la direccion original de sp
buc	
	cmp r9, r10
	beq finbuc
	mul r12, r10, r8        ; r12 = o * input_size   (elementos)
    mov r12, r12, LSL #1    ; r12 = o * input_size * 2  (bytes, los datos son de "half word")
    add r1,  r5, r12        ; r1 = weights_o  preparamos el peso para neuron
	mov r12, r10, LSL #1    ; r12 = o*2 (bytes) — reutilizamos r12
    ldrsh r3, [r6, r12]     ; r3 = bias[o], para neuron
	mov r0, r4				; r0=input (primer argumento de neuron)
	mov r2, r8				; r2=input_size (tercer argumento de neuron)
	bl neuron_q12_Deprecated
	mov r12, r10, LSL #1
	strh r0, [r7, r12]		; output[o] = y
	add r11, r11, r11, LSL #5	; checksum=checksum*33u (añadir a memoria que hay otra solucion (mul r11, #33, r11)
	mov r0, r0, LSL #16
	mov r0, r0, LSR #16		; (uint16_t)y, añadir a memoria, se "empujan" los primeros 16 bits y luego se añaden 0s con LSR, para evitar tener datos con "basura"
	add r11, r11, r0
	add r10, r10, #1
	b buc
finbuc
	add sp, sp, #8			;"Desapilamos" los clamps de neuron
	mov r0, r11				; Devuelve el resultado de checksum en r0, como es un argumento a punto de salir se puede machacar el resultado de r0
	add sp, sp, #4
	POP {r4-r11, pc}
	
	END
